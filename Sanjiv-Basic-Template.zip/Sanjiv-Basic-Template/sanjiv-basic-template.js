define( [
        'jquery', './properties', 'text!./main.css',
    ],
    function ( $ , props, cssContent ) {
        'use strict';
		$( '<style>' ).html(cssContent).appendTo( 'head' );
        return {
			// Define what our properties panel look like
			definition: props,
			initialProperties: {
				qHyperCubeDef: {
					qDimensions: [],
					qMeasures: [],
					qInitialDataFetch: [
						{
							qWidth: 10,
							qHeight: 100
						}
					]
				} 
			},
            //Paint resp.Rendering logic
            paint: function ( $element, layout ) {
				var dynamicData = layout.qHyperCube;
				console.log('Data Coming in console or not: ', dynamicData); //Note:- This line "console.log" only for debugging purpose.
				//console.log( layout ); //we add a console output to double-check where to find the object to reference in our code.
				$element.empty(); //empty() method using becausepaint method is called every time the visualization extension is rendered and therefore resizing the visualization extension triggers the paint method. This means that a new $basicExtension object is appended to $element on every resize.
				
				
				
                /*var $basicExtension = $( document.createElement( 'div' ) );
				console.log($basicExtension);
                $basicExtension.html( layout.props.myTextbox );
                $element.append( $basicExtension );*/
				//debugger;
				var $basicExtension = $( document.createElement( 'div' ) );
				var $basicExtensionClass = $basicExtension.addClass('abc');
				//Adding Table inside of div
				var table = '<table border="1" cellpadding="0">';
					table += '<thead>';
						table += '<tr>';
								for (var i = 0; i < dynamicData.qDimensionInfo.length; i++) {
								table += '<th>' + dynamicData.qDimensionInfo[i].qFallbackTitle + '</th>';
							}
							for (var i = 0; i < dynamicData.qMeasureInfo.length; i++) {
								table += '<th>' + dynamicData.qMeasureInfo[i].qFallbackTitle + '</th>';
							}
						table += '</tr>';
					table += '</thead>';
					
					table += '<tbody>';
						// iterate over all rows
						for (var r = 0; r < dynamicData.qDataPages[0].qMatrix.length; r++) {
							table += '<tr>';

							// iterate over all cells within a row
							for (var c = 0; c < dynamicData.qDataPages[0].qMatrix[r].length; c++) {
								table += '<td>';
									table += dynamicData.qDataPages[0].qMatrix[r][c].qText;
								table += '</td>';
							}
							table += '</tr>';
						}
					table += '</tbody>';
					table += '</table>';
					//$basicExtension.html( layout.table );
					var addTable = $basicExtensionClass.append(table);
				$element.append(addTable);	
				if (layout.props.myCheckBox == false) {
					debugger;
					$('.abc table tbody tr td:first-child').removeClass("change-color");
					console.log('Not Checked');
				
				}
				else if (layout.props.myCheckBox !== false) {
					$('.abc table tbody tr td:first-child').addClass("change-color");
					console.log('Checked');
					}
				
				/*$('input:checkbox').change(function(){
					if($(this).is(":checked")) {
						
						$('.abc table tbody tr td:first-child').addClass("change-color");
						console.log('Checked');
					} else {
						$('.abc table tbody tr td:first-child').removeClass("change-color");
						console.log('Not Checked');
					}
				});*/
	
            }
        };
    } );