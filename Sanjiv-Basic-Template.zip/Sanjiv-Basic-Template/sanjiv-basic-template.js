define( [
        'jquery', './properties'
    ],
    function ( $ , props ) {
        'use strict';

        return {
			// Define what our properties panel look like
			definition: props,
            //Paint resp.Rendering logic
            paint: function ( $element, layout ) {
				//console.log( layout ); //we add a console output to double-check where to find the object to reference in our code.
				$element.empty(); //empty() method using becausepaint method is called every time the visualization extension is rendered and therefore resizing the visualization extension triggers the paint method. This means that a new $basicExtension object is appended to $element on every resize.

                var $basicExtension = $( document.createElement( 'div' ) );
				console.log($basicExtension);
                $basicExtension.html( layout.myDynamicOutput );
                $element.append( $basicExtension );

            }
        };
    } );